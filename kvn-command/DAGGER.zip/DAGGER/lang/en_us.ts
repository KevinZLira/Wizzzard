export type Dictionary = {
  "spellbook.open": "Unsheathe Dagger",
  "spellbook.settings": "Open Settings",
  "spellbook.video": "Video Effects",
  "spellbook.audio": "Audio Effects"
}